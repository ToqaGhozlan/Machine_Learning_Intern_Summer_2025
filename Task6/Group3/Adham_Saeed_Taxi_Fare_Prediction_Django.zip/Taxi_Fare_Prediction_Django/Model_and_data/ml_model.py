import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, OrdinalEncoder, RobustScaler, StandardScaler, PowerTransformer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, root_mean_squared_error
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split, RandomizedSearchCV, KFold
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
import pickle


df = pd.read_csv('train.csv', parse_dates = ['pickup_datetime'])

df.rename(
   
   columns = {
      'Car Condition': 'Car_Condition',
      'Traffic Condition': 'Traffic_Condition'
   }
   , inplace = True
)



numerical_features = df.select_dtypes(include = (int, float))
numerical_features.columns

categorical_features = df.select_dtypes(object)
categorical_features.columns


q1_distance = df['distance'].quantile(0.3)
q2_distance = df['distance'].quantile(0.99999)
min = df['distance'].min()
max = df['distance'].max()

q1_fare = df['fare_amount'].quantile(0.01)
q2_fare = df['fare_amount'].quantile(0.95)
fare_amount_min_value = df['fare_amount'].min()
fare_amount_max_value = df['fare_amount'].max()





features = df.drop(['fare_amount', 'User ID', 'User Name', 'Driver Name', 'key', 'pickup_datetime'], axis = 1)
target = df['fare_amount']

x_train, x_test, y_train, y_test = train_test_split(features, target, test_size = 0.3, random_state = 42)

main_categorical_features = categorical_features.drop(['User ID', 'User Name', 'Driver Name', 'key'], axis = 1)

x_train[main_categorical_features.columns].head()

for column in main_categorical_features.columns:
  order = df.groupby(column)['fare_amount'].mean()

car_conditions = ['Bad', 'Good', 'Excellent', 'Very Good']

weather_conditions = ['stormy', 'windy', 'rainy', 'sunny', 'cloudy']

traffic_conditions = ['Flow Traffic', 'Dense Traffic', 'Congested Traffic']


categories = [car_conditions, weather_conditions, traffic_conditions]

ordinal_encoder = OrdinalEncoder(categories = categories)



x_train_encoded = x_train.copy()
x_test_encoded = x_test.copy()

x_train_encoded[main_categorical_features.columns] = ordinal_encoder.fit_transform(x_train[main_categorical_features.columns])
x_test_encoded[main_categorical_features.columns] = ordinal_encoder.transform(x_test[main_categorical_features.columns])
x_test_encoded[main_categorical_features.columns].head()

distance_lower_bound = q1_distance
distance_upper_bound = q2_distance
x_train_encoded['distance'] = x_train['distance'].clip(distance_lower_bound, distance_upper_bound)





fare_lower_bound = q1_fare
fare_upper_bound = q2_fare

y_train = pd.DataFrame(y_train)

y_train = y_train.clip(fare_lower_bound, fare_upper_bound)




imputer = SimpleImputer(missing_values = np.nan, strategy = 'median')
x_train_imputed = x_train_encoded.copy()
x_test_imputed = x_test_encoded.copy()

main_numerical_features = numerical_features.drop('fare_amount', axis = 1)

x_train_imputed[main_numerical_features.columns] = imputer.fit_transform(x_train_encoded[main_numerical_features.columns])
x_test_imputed[main_numerical_features.columns] = imputer.transform(x_test_encoded[main_numerical_features.columns])

x_train_scaled = x_train_imputed.copy()
x_test_scaled = x_test_imputed.copy()


robust_scaler = RobustScaler()

x_train_scaled[main_numerical_features.columns] = robust_scaler.fit_transform(x_train_imputed[main_numerical_features.columns])
x_test_scaled[main_numerical_features.columns] = robust_scaler.transform(x_test_imputed[main_numerical_features.columns])


# pca_features1 = ['pickup_longitude', 'pickup_latitude',
#        'dropoff_longitude', 'dropoff_latitude']

# pca_features2 = ['jfk_dist', 'ewr_dist', 'lga_dist',
#        'sol_dist', 'nyc_dist']

# pca = PCA()

# pca.fit(x_train_scaled[pca_features1])

# var = pca.explained_variance_ratio_



# pca1 = PCA(n_components = 2)

# pca2 = PCA(n_components = 1)

# pca_columns_train1 = pd.DataFrame(pca1.fit_transform(x_train_scaled[pca_features1]), columns = ['PC1', 'PC2'])
# pca_columns_test1 = pd.DataFrame(pca1.transform(x_test_scaled[pca_features1]), columns = ['PC1', 'PC2'])

# pca_columns_train2 = pd.DataFrame(pca2.fit_transform(x_train_scaled[pca_features2]), columns = ['PC3'])
# pca_columns_test2 = pd.DataFrame(pca2.transform(x_test_scaled[pca_features2]), columns = ['PC3'])

# # pca_columns_train
# x_train_scaled = x_train_scaled.copy()
# x_test_scaled = x_test_scaled.copy()

# x_train_scaled = pd.concat([x_train_scaled.drop(columns = pca_features1 + pca_features2).reset_index(drop = True), pca_columns_train1, pca_columns_train2], axis = 1)
# x_test_scaled = pd.concat([x_test_scaled.drop(columns = pca_features1 + pca_features2).reset_index(drop = True), pca_columns_test1, pca_columns_test2], axis = 1)
# x_test_scaled



dt = DecisionTreeRegressor()

dt.fit(x_train_scaled, y_train)

predictions = dt.predict(x_test_scaled)

MSE = mean_squared_error(y_test, predictions)
RMSE = root_mean_squared_error(y_test, predictions)
MAE = mean_absolute_error(y_test, predictions)
R2 = r2_score(y_test, predictions)

print(MSE, RMSE, MAE, R2)

kf = KFold(n_splits=5, shuffle=True, random_state=42)
param_grid = {
    'max_depth' : [10, 20, 30, 40, 50],
    'min_samples_split' : [2, 5, 10, 20]
}

dt_cv = RandomizedSearchCV(dt, param_grid, cv=kf, n_iter=2)
dt_cv.fit(x_train_scaled, y_train)
print(dt_cv.best_params_, dt_cv.best_score_)




with open('bundle.pkl', 'wb') as f:
    pickle.dump({
    "ordinal_encoder": ordinal_encoder,
    "robust_scaler" :robust_scaler,
    "model" : dt_cv,
    }, f)

print(x_train_scaled.columns)























# knn = KNeighborsRegressor()

# knn.fit(x_train_scaled, y_train)

# predictions = knn.predict(x_test_scaled)



# # 1. Create polynomial features of degree 2 (can be 3, 4, etc.)
# from sklearn.preprocessing import PolynomialFeatures
# from sklearn.pipeline import make_pipeline
# poly_model = make_pipeline(PolynomialFeatures(degree=2), LinearRegression())

# # 2. Fit the model
# poly_model.fit(x_train_scaled, y_train)

# # 3. Predict
# y_pred = poly_model.predict(x_test_scaled)



# gb = GradientBoostingRegressor()

# gb.fit(x_train_scaled, y_train)

# predictions = gb.predict(x_test_scaled)



# print(MSE, RMSE, MAE, R2)

# adaboost = AdaBoostRegressor()

# adaboost.fit(x_train_scaled, y_train)

# predictions = adaboost.predict(x_test_scaled)





