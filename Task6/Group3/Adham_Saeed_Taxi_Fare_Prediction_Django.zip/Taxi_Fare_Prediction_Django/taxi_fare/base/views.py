from django.shortcuts import render
import pickle
import numpy as np
import pandas as pd


# Load model and transformers once
with open('..\\Model_and_data\\bundle.pkl', 'rb') as f:
    saved = pickle.load(f)
    model = saved['model']
    ordinal_encoder = saved['ordinal_encoder']
    robust_scaler = saved['robust_scaler']


def home(request):
    return render(request, 'index.html')


def getPredictions(Car_Condition, Weather, Traffic_Condition,
                   pickup_longitude, pickup_latitude,
                   dropoff_longitude, dropoff_latitude,
                   passenger_count, hour, day, month, weekday, year,
                   jfk_dist, ewr_dist, lga_dist, sol_dist, nyc_dist,
                   distance, bearing):

    # Step 1: Build input as DataFrame
    df_input = pd.DataFrame([[
        Car_Condition, Weather, Traffic_Condition,
        pickup_longitude, pickup_latitude,
        dropoff_longitude, dropoff_latitude,
        passenger_count, hour, day, month, weekday, year,
        jfk_dist, ewr_dist, lga_dist, sol_dist, nyc_dist,
        distance, bearing
    ]], columns=[
        'Car_Condition', 'Weather', 'Traffic_Condition',
        'pickup_longitude', 'pickup_latitude',
        'dropoff_longitude', 'dropoff_latitude',
        'passenger_count', 'hour', 'day', 'month', 'weekday', 'year',
        'jfk_dist', 'ewr_dist', 'lga_dist', 'sol_dist', 'nyc_dist',
        'distance', 'bearing'
    ])

    # Step 2: Encode ordinal features
    ordinal_features = ['Car_Condition', 'Weather', 'Traffic_Condition']
    df_input[ordinal_features] = ordinal_encoder.transform(df_input[ordinal_features])

    # Step 3: Scale numerical features
    numerical_features = [  # match training numerical features
        'pickup_longitude', 'pickup_latitude',
        'dropoff_longitude', 'dropoff_latitude',
        'passenger_count', 'hour', 'day', 'month', 'weekday', 'year',
        'jfk_dist', 'ewr_dist', 'lga_dist', 'sol_dist', 'nyc_dist',
        'distance', 'bearing'
    ]
    df_input[numerical_features] = robust_scaler.transform(df_input[numerical_features])

    # Step 4: Predict fare
    prediction = model.predict(df_input)[0]

    return round(prediction, 2)  # rounded fare amount


def result(request):
    # Read values from GET request (cast as needed)
    Car_Condition = request.GET['Car_Condition']
    Weather = request.GET['Weather']
    Traffic_Condition = request.GET['Traffic_Condition']

    pickup_longitude = float(request.GET['pickup_longitude'])
    pickup_latitude = float(request.GET['pickup_latitude'])
    dropoff_longitude = float(request.GET['dropoff_longitude'])
    dropoff_latitude = float(request.GET['dropoff_latitude'])
    passenger_count = int(request.GET['passenger_count'])
    hour = int(request.GET['hour'])
    day = int(request.GET['day'])
    month = int(request.GET['month'])
    weekday = int(request.GET['weekday'])
    year = int(request.GET['year'])
    jfk_dist = float(request.GET['jfk_dist'])
    ewr_dist = float(request.GET['ewr_dist'])
    lga_dist = float(request.GET['lga_dist'])
    sol_dist = float(request.GET['sol_dist'])
    nyc_dist = float(request.GET['nyc_dist'])
    distance = float(request.GET['distance'])
    bearing = float(request.GET['bearing'])

    # Call the prediction function
    result = getPredictions(Car_Condition, Weather, Traffic_Condition,
                            pickup_longitude, pickup_latitude,
                            dropoff_longitude, dropoff_latitude,
                            passenger_count, hour, day, month, weekday, year,
                            jfk_dist, ewr_dist, lga_dist, sol_dist, nyc_dist,
                            distance, bearing)

    return render(request, 'result.html', {'result': result})
