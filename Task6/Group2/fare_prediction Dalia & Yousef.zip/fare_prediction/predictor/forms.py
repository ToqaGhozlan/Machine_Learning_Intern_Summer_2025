from django import forms

class FareForm(forms.Form):
    pickup_longitude = forms.FloatField(label="Pickup Longitude")
    pickup_latitude = forms.FloatField(label="Pickup Latitude")
    dropoff_longitude = forms.FloatField(label="Dropoff Longitude")
    dropoff_latitude = forms.FloatField(label="Dropoff Latitude")
    passenger_count = forms.IntegerField(label="Passenger Count")
