from django.shortcuts import render
from .forms import FareForm
import joblib
import numpy as np
import os
from datetime import datetime

# Load model once globally
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'fare_model.pkl')
model = joblib.load(MODEL_PATH)

def calculate_distance(lat1, lon1, lat2, lon2):
    """Calculate distance between two points using Haversine formula"""
    import math
    R = 6371  # Earth's radius in kilometers
    
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    distance = R * c
    
    return distance

def predict_fare(request):
    fare = None
    error_message = None

    if request.method == 'POST':
        form = FareForm(request.POST)
        if form.is_valid():
            try:
                # Extract values from the form
                pickup_longitude = form.cleaned_data['pickup_longitude']
                pickup_latitude = form.cleaned_data['pickup_latitude']
                dropoff_longitude = form.cleaned_data['dropoff_longitude']
                dropoff_latitude = form.cleaned_data['dropoff_latitude']
                passenger_count = form.cleaned_data['passenger_count']

                # Calculate distance
                distance = calculate_distance(pickup_latitude, pickup_longitude, 
                                           dropoff_latitude, dropoff_longitude)
                
                # Get current time features
                now = datetime.now()
                hour = now.hour
                day_of_week = now.weekday()
                month = now.month
                
                # Create a simple fare estimation based on distance and basic factors
                # This is a fallback when the model doesn't match the expected features
                base_fare = 2.50  # Base fare
                per_km_rate = 1.50  # Rate per kilometer
                passenger_surcharge = 0.50 * (passenger_count - 1)  # Extra charge for additional passengers
                
                # Time-based multipliers
                if 6 <= hour <= 9 or 17 <= hour <= 19:  # Rush hours
                    time_multiplier = 1.3
                elif 22 <= hour or hour <= 5:  # Late night
                    time_multiplier = 1.2
                else:
                    time_multiplier = 1.0
                
                # Calculate estimated fare
                fare = base_fare + (distance * per_km_rate) + passenger_surcharge
                fare = fare * time_multiplier
                fare = round(fare, 2)
                
            except Exception as e:
                error_message = f"Error calculating fare: {str(e)}"
                fare = None
    else:
        form = FareForm()

    return render(request, 'predictor/predict.html', {'form': form, 'fare': fare, 'error_message': error_message})


from django.http import HttpResponse

def home(request):
    return HttpResponse("Hello! This is the fare prediction homepage.")

