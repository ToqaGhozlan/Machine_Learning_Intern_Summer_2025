from django.shortcuts import render

def home(request):
    return render(request, 'fare_app/home.html')
