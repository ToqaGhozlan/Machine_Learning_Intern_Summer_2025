from django.apps import AppConfig


class FareAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "fare_app"
