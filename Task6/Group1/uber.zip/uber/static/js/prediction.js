document.addEventListener('DOMContentLoaded', () => {
    const data = safeParse(localStorage.getItem('predictionData'));
    const predictions = safeParse(localStorage.getItem('predictionResults'));

    if (!data || !predictions) {
        alert('No prediction data found. Redirecting to input form.');
        window.location.href = '/';
        return;
    }

    displayPredictions(predictions, data);
    setupDownload(predictions, data);

    // Clear storage to avoid old data
    localStorage.removeItem('predictionData');
    localStorage.removeItem('predictionResults');
});

/* ------------ Display Predictions ------------ */
function displayPredictions(predictions, data) {
    // Prediction score
    const scoreEl = document.querySelector('#predictionScore .score-value');
    if (scoreEl) scoreEl.textContent = `${predictions.accuracy}%`;

    // Metrics
    setText('#estimatedDuration', `${Math.round(predictions.estimated_duration)} minutes`);
    setText('#predictedFare', `$${predictions.predicted_fare.toFixed(2)}`);
    setText('#routeEfficiency', `${Math.round(predictions.route_efficiency)}%`);

    // Trip details
    const details = [
        { label: 'Trip ID', value: data.tripKey },
        { label: 'User', value: data.userName },
        { label: 'Driver', value: data.driverName },
        { label: 'Distance', value: `${data.tripDistance} miles` },
        { label: 'Passengers', value: data.passengerCount },
        { label: 'Weather', value: capitalizeFirst(data.weather) },
        { label: 'Traffic', value: capitalizeFirst(data.traffic) },
        { label: 'Car Condition', value: capitalizeFirst(data.carCondition) },
        { label: 'Pickup Time', value: formatDateTime(data.pickupDatetime) },
        { label: 'Bearing', value: `${data.bearing}°` },
        { label: 'JFK Distance', value: `${data.jfkDistance} miles` },
        { label: 'EWR Distance', value: `${data.ewrDistance} miles` },
        { label: 'LGA Distance', value: `${data.lgaDistance} miles` },
        { label: 'Statue of Liberty Distance', value: `${data.solDistance} miles` }
    ];

    const detailsContainer = document.getElementById('tripDetails');
    if (detailsContainer) {
        detailsContainer.innerHTML = details.map(d => `
            <div class="detail-item">
                <span class="detail-label">${d.label}:</span>
                <span class="detail-value">${d.value ?? '--'}</span>
            </div>
        `).join('');
    }

    // Key factors & recommendations
    setList('#keyFactors', predictions.key_factors);
    setList('#recommendations', predictions.recommendations);

    // Coordinates
    setText('#pickupCoords', `${parseFloat(data.pickupLatitude).toFixed(4)}, ${parseFloat(data.pickupLongitude).toFixed(4)}`);
    setText('#dropoffCoords', `${parseFloat(data.dropoffLatitude).toFixed(4)}, ${parseFloat(data.dropoffLongitude).toFixed(4)}`);
}

/* ------------ Download Report ------------ */
function setupDownload(predictions, data) {
    const btn = document.getElementById('downloadBtn');
    if (!btn) return;

    btn.addEventListener('click', () => {
        const report = {
            timestamp: new Date().toISOString(),
            tripDetails: data,
            predictions: predictions,
            summary: {
                tripId: data.tripKey,
                user: data.userName,
                driver: data.driverName,
                estimatedDuration: `${predictions.estimated_duration} minutes`,
                predictedFare: `$${predictions.predicted_fare.toFixed(2)}`,
                routeEfficiency: `${Math.round(predictions.route_efficiency)}%`,
                predictionAccuracy: `${predictions.accuracy}%`
            }
        };

        downloadReport(JSON.stringify(report, null, 2));
    });
}

function downloadReport(content) {
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = `ride-prediction-report-${Date.now()}.json`;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

/* ------------ Helpers ------------ */
function safeParse(json) {
    try {
        return JSON.parse(json);
    } catch {
        return null;
    }
}

function setText(selector, text) {
    const el = document.querySelector(selector);
    if (el) el.textContent = text ?? '--';
}

function setList(selector, items) {
    const el = document.querySelector(selector);
    if (el && Array.isArray(items)) {
        el.innerHTML = items.map(item => `<li>${item}</li>`).join('');
    }
}

function capitalizeFirst(str) {
    return str ? str.charAt(0).toUpperCase() + str.slice(1) : '';
}

function formatDateTime(dateTimeStr) {
    const date = new Date(dateTimeStr);
    return isNaN(date) ? '--' : date.toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}
