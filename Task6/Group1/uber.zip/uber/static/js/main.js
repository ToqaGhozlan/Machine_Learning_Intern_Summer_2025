document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('predictionForm');
    const userIdField = document.getElementById('userId');
    const tripKeyField = document.getElementById('tripKey');
    const pickupDatetime = document.getElementById('pickupDatetime');

    // Generate default IDs and datetime
    const setDefaultValues = () => {
        userIdField.value = `USER${Date.now().toString().slice(-6)}`;
        tripKeyField.value = `TRIP${Date.now().toString().slice(-6)}`;
        pickupDatetime.value = new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
            .toISOString()
            .slice(0, 16);
    };
    setDefaultValues();

    // Form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!validateForm()) return;

        const formData = Object.fromEntries(new FormData(form).entries());
        const datetime = new Date(formData.pickupDatetime);

        // Add derived datetime fields
        Object.assign(formData, {
            hour: datetime.getHours(),
            day: datetime.getDate(),
            month: datetime.getMonth() + 1,
            week: getWeekNumber(datetime),
            dayOfWeek: datetime.getDay()
        });

        showLoadingState();
        try {
            const response = await fetch('/api/predict/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                },
                body: JSON.stringify(formData)
            });
            const result = await response.json();

            if (result.success) {
                localStorage.setItem('predictionData', JSON.stringify(formData));
                localStorage.setItem('predictionResults', JSON.stringify(result.predictions));
                window.location.href = '/prediction/';
            } else {
                alert(`Error: ${result.error}`);
                resetLoadingState();
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while processing your request.');
            resetLoadingState();
        }
    });

    // Reset button regenerates IDs
    form.querySelector('button[type="reset"]').addEventListener('click', () => {
        setTimeout(setDefaultValues, 100);
    });

    // Live validation
    form.querySelectorAll('input, select').forEach(input => {
        input.addEventListener('blur', () => validateField(input));
        input.addEventListener('input', () => {
            if (input.classList.contains('invalid')) validateField(input);
        });
    });
});

/* ------------ Validation Functions ------------ */
function validateForm() {
    let isValid = true;
    document.querySelectorAll('#predictionForm input[required], #predictionForm select[required]')
        .forEach(input => { if (!validateField(input)) isValid = false; });

    // Custom checks
    const fareAmount = document.getElementById('fareAmount');
    if (parseFloat(fareAmount.value) <= 0) {
        showFieldError(fareAmount, 'Fare amount must be greater than 0');
        isValid = false;
    }

    const passengerCount = document.getElementById('passengerCount');
    if (passengerCount.value < 1 || passengerCount.value > 8) {
        showFieldError(passengerCount, 'Passenger count must be between 1 and 8');
        isValid = false;
    }

    // Coordinate bounds
    ['pickupLongitude', 'pickupLatitude', 'dropoffLongitude', 'dropoffLatitude'].forEach(id => {
        const field = document.getElementById(id);
        const val = parseFloat(field.value);
        if (id.includes('Longitude') && (val < -180 || val > 180)) {
            showFieldError(field, 'Longitude must be between -180 and 180');
            isValid = false;
        }
        if (id.includes('Latitude') && (val < -90 || val > 90)) {
            showFieldError(field, 'Latitude must be between -90 and 90');
            isValid = false;
        }
    });

    return isValid;
}

function validateField(field) {
    removeFieldError(field);
    const value = field.value.trim();

    if (field.required && !value) {
        showFieldError(field, 'This field is required');
        return false;
    }
    if (field.type === 'email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        showFieldError(field, 'Please enter a valid email address');
        return false;
    }
    if (field.type === 'number') {
        const num = parseFloat(value);
        if (isNaN(num)) {
            showFieldError(field, 'Please enter a valid number');
            return false;
        }
        if (field.min && num < parseFloat(field.min)) {
            showFieldError(field, `Value must be at least ${field.min}`);
            return false;
        }
        if (field.max && num > parseFloat(field.max)) {
            showFieldError(field, `Value must be at most ${field.max}`);
            return false;
        }
    }
    return true;
}

function showFieldError(field, msg) {
    field.classList.add('invalid');
    const err = document.createElement('div');
    err.className = 'field-error';
    err.textContent = msg;
    err.style.cssText = 'color:#ef4444;font-size:0.875rem;margin-top:4px;';
    field.parentNode.appendChild(err);
}

function removeFieldError(field) {
    field.classList.remove('invalid');
    const existing = field.parentNode.querySelector('.field-error');
    if (existing) existing.remove();
}

/* ------------ UI State Functions ------------ */
function showLoadingState() {
    const btn = document.querySelector('.btn-primary');
    btn.disabled = true;
    btn.textContent = 'Processing...';
    btn.style.opacity = '0.7';
    const spinner = document.createElement('span');
    spinner.innerHTML = ' ⟳';
    spinner.style.animation = 'spin 1s linear infinite';
    btn.appendChild(spinner);
    if (!document.getElementById('loading-styles')) {
        const style = document.createElement('style');
        style.id = 'loading-styles';
        style.textContent = '@keyframes spin {from{transform:rotate(0deg);} to{transform:rotate(360deg);}}';
        document.head.appendChild(style);
    }
}

function resetLoadingState() {
    const btn = document.querySelector('.btn-primary');
    btn.disabled = false;
    btn.textContent = 'Generate Prediction';
    btn.style.opacity = '1';
}

function getWeekNumber(date) {
    const start = new Date(date.getFullYear(), 0, 1);
    const days = (date - start) / 86400000;
    return Math.ceil((days + start.getDay() + 1) / 7);
}
