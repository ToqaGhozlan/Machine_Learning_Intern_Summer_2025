import json
import pandas as pd
import joblib
import numpy as np
from django.http import JsonResponse
from django.shortcuts import render

# Load the trained pipeline (includes preprocessing + model)
pipeline = joblib.load('pipeline.pkl')  # Path relative to manage.py

# ===== Page Render Views =====
def index(request):
    return render(request, 'predictions/index.html')

def prediction_page(request):
    return render(request, 'predictions/prediction.html')

# ===== API for Prediction =====
def predict_view(request):
    if request.method == 'POST':
        try:
            # Load JSON data from request
            data = json.loads(request.body)

            # Convert to DataFrame
            df = pd.DataFrame([data])

            # Drop non-model fields that are UI-only
            drop_cols = ['userId', 'userName', 'driverName', 'tripKey']
            df_model = df.drop(columns=[col for col in drop_cols if col in df.columns], errors='ignore')

            # Make prediction
            predicted_fare = pipeline.predict(df_model)[0]

            # Example extra outputs (replace with your own logic if needed)
            predictions = {
                "accuracy": 83.9,  # Replace with actual model CV score if you want
                "estimated_duration": float(np.random.uniform(5, 25)),
                "predicted_fare": float(predicted_fare),
                "route_efficiency": float(np.random.uniform(80, 100)),
                "key_factors": ["Low traffic", "Good weather"],
                "recommendations": [
                    "Consider using UberPool for cost saving",
                    "Travel during off-peak hours"
                ]
            }

            return JsonResponse({"success": True, "predictions": predictions})

        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)}, status=400)

    return JsonResponse({"success": False, "error": "Invalid request"}, status=405)
