from django.db import models

class Prediction(models.Model):
    trip_key = models.CharField(max_length=150, unique=True)
    pickup_datetime = models.DateTimeField()
    pickup_latitude = models.FloatField()
    pickup_longitude = models.FloatField()
    dropoff_latitude = models.FloatField()
    dropoff_longitude = models.FloatField()
    passenger_count = models.IntegerField(default=1)
    distance = models.FloatField(null=True, blank=True)
    bearing = models.FloatField(null=True, blank=True)
    predicted_fare = models.FloatField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.trip_key} — {self.predicted_fare:.2f}"
