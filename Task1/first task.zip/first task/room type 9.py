# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 07:43:01 2025

@author: tuqam
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")
df.rename(columns=lambda x: x.strip(), inplace=True)

room_status = df.groupby(['room type', 'booking status']).size().unstack().fillna(0)

room_status['Total'] = room_status.sum(axis=1)
room_status['Cancel Rate (%)'] = (room_status['Canceled'] / room_status['Total']) * 100

print(room_status[['Total', 'Canceled', 'Cancel Rate (%)']].sort_values(by='Cancel Rate (%)', ascending=False))

plt.figure(figsize=(10, 5))
plt.bar(
    room_status.index,
    room_status['Cancel Rate (%)'],
    color='#FF6B6B',
    edgecolor='black'
)
plt.title('Cancellation Rate by Room Type', fontsize=14, fontweight='bold')
plt.xlabel('Room Type')
plt.ylabel('Cancellation Rate (%)')
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
