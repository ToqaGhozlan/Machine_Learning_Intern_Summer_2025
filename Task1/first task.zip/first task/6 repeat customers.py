# -*- coding: utf-8 -*-
"""
Created on Thu Jul  3 08:31:39 2025

@author: tuqam
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")

df.rename(columns=lambda x: x.strip(), inplace=True)

repeat_data = df.groupby(['repeated', 'booking status']).size().unstack()

repeat_data = repeat_data.reindex([0, 1])

ax = repeat_data.plot(
    kind='bar',
    stacked=False,
    figsize=(8, 6),
    color=['#4ECDC4', '#FF6B6B'],
    edgecolor='black'
)

plt.title('Impact of repeat customer on cancellation', fontsize=14, fontweight='bold')
plt.xlabel('Customer Type', fontsize=12)
plt.ylabel('Numer of Bookings', fontsize=12)
plt.xticks([0, 1], ['New', 'Repeat'], rotation=0, fontsize=11)
plt.yticks(fontsize=11)
plt.legend(title='Booling Status', labels=['Not Canceled', 'Canceled'])
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()