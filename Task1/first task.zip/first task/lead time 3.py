# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 04:46:16 2025

@author: tuqam
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")
df.rename(columns=lambda x: x.strip(), inplace=True)

df['lead_time_category'] = pd.qcut(df['lead time'], q=4, labels=['Short', 'Medium', 'Long', 'Very Long'])

lead_status = df.groupby(['lead_time_category', 'booking status']).size().unstack().fillna(0)

lead_status['Total'] = lead_status.sum(axis=1)
lead_status['Cancel Rate (%)'] = (lead_status['Canceled'] / lead_status['Total']) * 100

print(lead_status[['Total', 'Canceled', 'Cancel Rate (%)']])

plt.figure(figsize=(8, 5))
plt.bar(
    lead_status.index,
    lead_status['Cancel Rate (%)'],
    color='#FF6B6B',
    edgecolor='black'
)
plt.title('Cancellation Rate by Lead Time Category', fontsize=14, fontweight='bold')
plt.xlabel('Lead Time Category')
plt.ylabel('Cancellation Rate (%)')
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
