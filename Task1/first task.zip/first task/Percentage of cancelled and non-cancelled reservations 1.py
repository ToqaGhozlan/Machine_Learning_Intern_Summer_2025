import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")

status_counts = df['booking status'].value_counts()

plt.pie(
    status_counts,            
    labels=status_counts.index, 
    autopct='%1.1f%%'        
)

plt.title('Percentage of cancelled and non-cancelled reservations')
plt.show()
