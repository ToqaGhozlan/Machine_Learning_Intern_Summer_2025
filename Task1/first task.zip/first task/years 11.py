# -*- coding: utf-8 -*-
"""
Created on Wed Jul  2 09:11:19 2025

@author: tuqam
"""

# 📦 استيراد المكتبات
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 🌐 إعداد العرض البياني
sns.set(style="whitegrid")
plt.rcParams['figure.figsize'] = (10, 5)

# 📁 تحميل البيانات
df = pd.read_csv("first inten project (1).csv")  # ← غيّر الاسم حسب ملفك

# 🧹 تنظيف أسماء الأعمدة من المسافات
df.columns = df.columns.str.strip()

# 🟠 إنشاء عمود جديد يمثل الإلغاء (Canceled) للتسهيل
df['Canceled'] = df['P-C'] > 0
# 🔸 تحويل التاريخ
# تحويل العمود إلى نوع تاريخي
df['date of reservation'] = pd.to_datetime(df['date of reservation'], errors='coerce')

# استخراج السنة بعد التأكد من أن التنسيق صحيح
df['Year'] = df['date of reservation'].dt.year


# 🔸 تجاهل القيم المفقودة
df_year = df.dropna(subset=['Year'])

# 🔸 حساب نسبة الإلغاء لكل سنة
yearly_cancel = df_year.groupby('Year')['Canceled'].mean() * 100
print("\n🔹 نسبة الإلغاء حسب سنة الحجز:")
print(yearly_cancel)

# 🔸 رسم النسبة عبر السنوات
yearly_cancel.plot(kind='bar', color='tomato')
plt.title('Cancellation rate by booking year')
plt.xlabel("years")
plt.ylabel('Cancellation rate (%)')
plt.xticks(rotation=45)
plt.show()
