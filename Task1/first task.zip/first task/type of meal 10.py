
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 07:48:08 2025

@author: tuqam
"""
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")
df.rename(columns=lambda x: x.strip(), inplace=True)

meal_status = df.groupby(['type of meal', 'booking status']).size().unstack().fillna(0)

meal_status['Total'] = meal_status.sum(axis=1)
meal_status['Cancel Rate (%)'] = (meal_status['Canceled'] / meal_status['Total']) * 100

print(meal_status[['Total', 'Canceled', 'Cancel Rate (%)']].sort_values(by='Cancel Rate (%)', ascending=False))

plt.figure(figsize=(8, 5))
plt.bar(
    meal_status.index,
    meal_status['Cancel Rate (%)'],
    color='#FF6B6B',
    edgecolor='black'
)
plt.title('Cancellation Rate by Meal Type', fontsize=14, fontweight='bold')
plt.xlabel('Meal Type')
plt.ylabel('Cancellation Rate (%)')
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
