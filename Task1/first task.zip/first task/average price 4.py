# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 05:00:12 2025

@author: tuqam
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")
df.rename(columns=lambda x: x.strip(), inplace=True)

df['price_category'] = pd.qcut(df['average price'], q=4, labels=['Low', 'Mid-Low', 'Mid-High', 'High'])

price_status = df.groupby(['price_category', 'booking status']).size().unstack().fillna(0)

price_status['Total'] = price_status.sum(axis=1)
price_status['Cancel Rate (%)'] = (price_status['Canceled'] / price_status['Total']) * 100

print(price_status[['Total', 'Canceled', 'Cancel Rate (%)']])

plt.figure(figsize=(8, 5))
plt.bar(
    price_status.index,
    price_status['Cancel Rate (%)'],
    color='#FF6B6B',
    edgecolor='black'
)
plt.title('Cancellation Rate by Average Price Category', fontsize=14, fontweight='bold')
plt.xlabel('Average Price Category')
plt.ylabel('Cancellation Rate (%)')
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
