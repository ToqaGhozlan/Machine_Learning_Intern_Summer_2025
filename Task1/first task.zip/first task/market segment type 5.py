# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 05:06:00 2025

@author: tuqam
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")

market_status = df.groupby(['market segment type', 'booking status']).size().unstack()

market_status.plot(kind='bar', stacked=False, figsize=(12, 6), colormap='Set2')

plt.title('market segment type ')
plt.xlabel('types')
plt.ylabel('number of reservations')
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.legend(title='state')
plt.show()
