# -*- coding: utf-8 -*-
"""
Created on Wed Jul  2 12:11:45 2025

@author: tuqam
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")
df.rename(columns=lambda x: x.strip(), inplace=True)

summary = df.groupby('repeated')[['P-C', 'P-not-C']].sum()

summary['Customer Count'] = df.groupby('repeated').size()

summary['Avg P-C per Customer'] = summary['P-C'] / summary['Customer Count']
summary['Avg P-not-C per Customer'] = summary['P-not-C'] / summary['Customer Count']

print("\n🔎 Summary of Past Behavior by Customer Type (Repeated vs New):\n")
print(summary[['Customer Count', 'P-C', 'P-not-C', 'Avg P-C per Customer', 'Avg P-not-C per Customer']])

plt.figure(figsize=(8, 5))
bar_width = 0.35
x = [0, 1]

plt.bar(
    [i - bar_width/2 for i in x],
    summary['Avg P-C per Customer'],
    width=bar_width,
    label='Avg Past Cancellations (P-C)',
    color='#FF6B6B'
)

plt.bar(
    [i + bar_width/2 for i in x],
    summary['Avg P-not-C per Customer'],
    width=bar_width,
    label='Avg Past Completed Bookings (P-not-C)',
    color='#4ECDC4'
)

plt.xticks(x, ['New Customer (repeated=0)', 'Repeat Customer (repeated=1)'])
plt.title('Average Past Booking Behavior by Customer Type', fontsize=14, fontweight='bold')
plt.ylabel('Average Count per Customer')
plt.legend()
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
