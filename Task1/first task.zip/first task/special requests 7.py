# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 07:30:17 2025

@author: tuqam
"""
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")
df.rename(columns=lambda x: x.strip(), inplace=True)

special_status = df.groupby(['special requests', 'booking status']).size().unstack().fillna(0)

special_status['Total'] = special_status.sum(axis=1)
special_status['Cancel Rate (%)'] = (special_status['Canceled'] / special_status['Total']) * 100

filtered = special_status[special_status['Total'] >= 50]

print(filtered[['Total', 'Canceled', 'Cancel Rate (%)']])

plt.figure(figsize=(8, 5))
plt.plot(filtered.index, filtered['Cancel Rate (%)'], marker='o', color='#FF6B6B')
plt.title('Cancellation Rate by Number of Special Requests', fontsize=14, fontweight='bold')
plt.xlabel('Number of Special Requests')
plt.ylabel('Cancellation Rate (%)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
