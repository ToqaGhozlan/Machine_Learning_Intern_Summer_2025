import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")
df.rename(columns=lambda x: x.strip(), inplace=True)

def classify_stay(row):
    if row['number of weekend nights'] > 0 and row['number of week nights'] == 0:
        return 'Weekend Only'
    elif row['number of week nights'] > 0 and row['number of weekend nights'] == 0:
        return 'Week Only'
    else:
        return 'Mixed'

df['stay_type'] = df.apply(classify_stay, axis=1)

stay_status = df.groupby(['stay_type', 'booking status']).size().unstack().fillna(0)

stay_status['Total'] = stay_status.sum(axis=1)
stay_status['Cancel Rate (%)'] = (stay_status['Canceled'] / stay_status['Total']) * 100

print(stay_status[['Total', 'Canceled', 'Cancel Rate (%)']])

plt.figure(figsize=(7, 5))
plt.bar(
    stay_status.index,
    stay_status['Cancel Rate (%)'],
    color='#FF6B6B',
    edgecolor='black'
)
plt.title('Cancellation Rate by Stay Type (Week vs Weekend)', fontsize=14, fontweight='bold')
plt.xlabel('Stay Type')
plt.ylabel('Cancellation Rate (%)')
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
