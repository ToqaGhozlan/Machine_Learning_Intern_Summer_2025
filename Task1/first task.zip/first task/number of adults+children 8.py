# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 07:36:59 2025

@author: tuqam
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")
df.rename(columns=lambda x: x.strip(), inplace=True)

df['total_guests'] = df['number of adults'] + df['number of children']

guest_status = df.groupby(['total_guests', 'booking status']).size().unstack().fillna(0)

guest_status['Total'] = guest_status.sum(axis=1)
guest_status['Cancel Rate (%)'] = (guest_status['Canceled'] / guest_status['Total']) * 100

filtered_guest_status = guest_status[guest_status['Total'] >= 50]

print(filtered_guest_status[['Total', 'Canceled', 'Cancel Rate (%)']])

plt.figure(figsize=(10, 5))
plt.plot(filtered_guest_status.index, filtered_guest_status['Cancel Rate (%)'], marker='o', color='#FF6B6B')
plt.title('Cancellation Rate by Total Number of Guests', fontsize=14, fontweight='bold')
plt.xlabel('Total Guests (Adults + Children)')
plt.ylabel('Cancellation Rate (%)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
