# -*- coding: utf-8 -*-
"""
Created on Wed Jul  2 12:27:27 2025

@author: tuqam
"""
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("first inten project (1).csv")
df.rename(columns=lambda x: x.strip(), inplace=True)

repeat_customers = df[df['repeated'] == 1]

total_pc = repeat_customers['P-C'].sum()
total_pnc = repeat_customers['P-not-C'].sum()
total_history = total_pc + total_pnc

pc_percent = (total_pc / total_history) * 100 if total_history > 0 else 0
pnc_percent = (total_pnc / total_history) * 100 if total_history > 0 else 0

print("📊 Booking history for repeat customers (repeated = 1):\n")
print(f"- Total Past Cancellations (P-C): {total_pc}")
print(f"- Total Past Completed Bookings (P-not-C): {total_pnc}")
print(f"- Total Booking History: {total_history}")
print(f"- % Cancellations: {pc_percent:.2f}%")
print(f"- % Completed: {pnc_percent:.2f}%")

if total_history > 0:
    plt.figure(figsize=(6, 6))
    plt.pie(
        [total_pc, total_pnc],
        labels=['Past Cancellations (P-C)', 'Completed Bookings (P-not-C)'],
        autopct='%1.1f%%',
        colors=['#FF6B6B', '#4ECDC4'],
        startangle=90,
        wedgeprops={'edgecolor': 'white'}
    )
    plt.title('Booking History Breakdown for Repeat Customers (repeated = 1)', fontsize=13, fontweight='bold')
    plt.tight_layout()
    plt.show()
else:
    print("\n⚠️ No historical booking data found for repeat customers.")
