
from flask import Flask, request, render_template
import joblib
import numpy as np

app = Flask(__name__)

# Load model and preprocessors
model = joblib.load("model.pkl")
scaler = joblib.load("scaler.pkl")
label_encoders = joblib.load("label_encoders.pkl")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        form = request.form
        data = [
            int(form["adults"]),
            int(form["children"]),
            int(form["weekend"]),
            int(form["week"]),
            label_encoders["type of meal"].transform([form["meal"]])[0],
            int(form["parking"]),
            label_encoders["room type"].transform([form["room"]])[0],
            int(form["lead"]),
            label_encoders["market segment type"].transform([form["market"]])[0],
            int(form["repeated"]),
            int(form["pc"]),
            int(form["pnc"]),
            float(form["price"]),
            int(form["special"])
        ]
        scaled = scaler.transform([data])
        pred = model.predict(scaled)[0]
        result = "Will Be Canceled" if pred == 1 else "Not Canceled"
        return render_template("index.html", prediction=result)
    except Exception as e:
        return render_template("index.html", prediction=f"Error: {str(e)}")

if __name__ == "__main__":
    app.run(debug=True)
