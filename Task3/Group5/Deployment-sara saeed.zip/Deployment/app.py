from flask import Flask, render_template, request
import joblib
import pandas as pd

app = Flask(__name__)

# Load the saved model and columns
model = joblib.load('model.pkl')
features = joblib.load('features.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get user input from form
        data = {feature: float(request.form[feature]) for feature in features}
        df = pd.DataFrame([data])

        # Make prediction
        prediction = model.predict(df)[0]
        result = "Cancelled" if prediction == 1 else "Not Cancelled"
        return render_template('index.html', prediction=result)
    
    except Exception as e:
        return render_template('index.html', prediction="Error: " + str(e))

if __name__ == '__main__':
    app.run(debug=True)
