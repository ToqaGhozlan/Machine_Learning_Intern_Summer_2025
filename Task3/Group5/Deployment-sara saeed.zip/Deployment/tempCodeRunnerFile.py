# model_training.py

# Step 1: Import Libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# Optional styling (only works in notebooks, can be skipped in .py)
# sns.set(style='whitegrid')  # Not necessary in .py script

# Step 2: Load and preprocess data
df = pd.read_csv('table.csv')  # Make sure the file is in the same folder
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

# Encode booking_status
df['cancelled'] = df['booking_status'].apply(lambda x: 1 if x.lower() == 'canceled' else 0)
df.drop('booking_status', axis=1, inplace=True)

# Encode categorical features
df['room_type'] = df['room_type'].astype('category').cat.codes
df['type_of_meal'] = df['type_of_meal'].astype('category').cat.codes
df['market_segment_type'] = df['market_segment_type'].astype('category').cat.codes

# Drop unnecessary columns
df.drop(['booking_id', 'date_of_reservation'], axis=1, inplace=True)

# Step 3: Train-test split
X = df.drop('cancelled', axis=1)
y = df['cancelled']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 4: Train the model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Step 5: Predictions
y_pred = model.predict(X_test)

# Step 6: Evaluation
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))

import joblib
joblib.dump(model, 'logistic_model.pkl')
print("Model saved successfully as logistic_model.pkl")