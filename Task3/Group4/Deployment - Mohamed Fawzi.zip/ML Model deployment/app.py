from flask import Flask, request, jsonify, render_template
import joblib
import numpy as np

app = Flask(__name__)
model = joblib.load("hotel_booking_model.pkl")  # Load your model

@app.route('/')
def home():
    return render_template('index.html')  # Optional UI form

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    features = np.array([
        data['number_of_adults'],
        data['number_of_children'],
        data['number_of_weekend_nights'],
        data['number_of_week_nights'],
        data['type_of_meal'],
        data['car_parking_space'],
        data['room_type'],
        data['lead_time'],
        data['market_segment_type'],
        data['repeated'],
        data['P_C'],
        data['P_not_C'],
        data['average_price'],
        data['special_requests']
    ]).reshape(1, -1)

    prediction = model.predict(features)[0]
    return jsonify({'booking_status': int(prediction)})

if __name__ == '__main__':
    app.run(debug=True)