import pandas as pd
from sklearn.model_selection import train_test_split
from scipy.stats import zscore
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE
import pickle


def month_arr(date):
    parts = date.split("/")
    if len(parts) == 1:
        parts = date.split("-")
        mon = parts[1]
        day = parts[2]
    else:
        mon = parts[0]
        day = parts[1]
    return mon, day


def more_than_year(data):
    year = 0
    while data > 12:
        data = data - 12
        year += 1
    return data


def remove_outliers_iqr(data, column):

    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1

    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    return data[(data[column] >= lower_bound) & (data[column] <= upper_bound)]


def remove_outliers_zscore(data, column, threshold=3):

    z_scores = zscore(data[column])
    mask = abs(z_scores) < threshold
    return data[mask]


# read dataset
path = r"C:\Users\eslamia\Desktop\deployment\first inten project.csv"
data = pd.read_csv(path)

# getting chek in featuer
data[["month", "day"]] = pd.DataFrame(
    data["date of reservation"].apply(month_arr).tolist(), index=data.index
)
data["month"] = data["month"].astype(int)
data["day"] = data["day"].astype(int)
data["month of arrive"] = data["month"] + (data["day"] + data["lead time"]) // 30
data["month of arrive"] = pd.DataFrame(
    data["month of arrive"].apply(more_than_year).tolist(), index=data.index
)

# featuer encoding
data = pd.get_dummies(
    data, columns=["type of meal", "room type", "market segment type"], dtype="int8"
)
data["booking status"] = data["booking status"] != "Canceled"
data["booking status"] = data["booking status"].astype("int8")


# featuer selection
data.drop(
    [
        "Booking_ID",
        "date of reservation",
        "day",
        "month",
        "market segment type_Offline",
        "type of meal_Not Selected",
        "type of meal_Meal Plan 3",
        "room type_Room_Type 2",
        "room type_Room_Type 3",
        "room type_Room_Type 5",
        "market segment type_Aviation",
        "room type_Room_Type 4",
        "P-C",
        "P-not-C",
    ],
    axis=1,
    inplace=True,
)

# removing outliers
data = remove_outliers_iqr(data, "lead time")
data = remove_outliers_zscore(data, "average price ")


# seprate featuers and target
X = data.drop(["booking status"], axis=1)
Y = data["booking status"]


# split dataset to train and test
X_train, x_test, y_train, y_test = train_test_split(
    X, Y, train_size=0.75, test_size=0.25, random_state=42
)


# scaling the featuers
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(x_test)
pickle.dump(scaler, open("scaler.pkl", "wb"))
# fixing unbalanced data


smote = SMOTE(random_state=42)
X_train_smote, y_train_smote = smote.fit_resample(X_train_scaled, y_train)


# fit model
model = RandomForestClassifier(random_state=42)
model.fit(X_train_smote, y_train_smote)


# pickel

pickle.dump(model, open("model.pkl", "wb"))
