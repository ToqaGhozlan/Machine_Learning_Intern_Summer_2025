import pickle
import numpy as np
import os
import warnings
import joblib
from flask import Flask, request, render_template, jsonify

# Suppress scikit-learn version warnings
warnings.filterwarnings('ignore', category=UserWarning)

app = Flask(__name__)

# Initialize variables
preprocessor = None
selector = None
pca = None
xgb_model = None
svm_model = None
rf_model = None

# Function to safely load pickle files
def load_pickle(filepath):
    try:
        # First try with joblib as it's more efficient for large numpy arrays
        try:
            # Suppress specific warnings about version mismatches
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=UserWarning)
                return joblib.load(filepath)
        except Exception as e:
            print(f"Joblib load failed for {filepath}, trying pickle...")
            
        # If joblib fails, try with pickle
        try:
            with open(filepath, 'rb') as f:
                return pickle.load(f)
        except Exception as e:
            print(f"Pickle load also failed for {filepath}: {str(e)}")
            return None
            
    except Exception as e:
        print(f"Unexpected error loading {filepath}: {str(e)}")
        return None

print("Loading models and preprocessing objects...")

# Load pipeline steps
preprocessor = load_pickle('saved_models/preprocessor.pkl')

# Try to load selector, but continue without it if it fails
selector = load_pickle('saved_models/selector.pkl')
if selector is None:
    print("Warning: Could not load selector. Continuing without feature selection.")

# Load PCA
pca = load_pickle('saved_models/pca_transformer.pkl')
if pca is None:
    print("Warning: Could not load PCA transformer. Continuing without PCA.")

# Load only Random Forest model
rf_model = load_pickle('saved_models/random_forest_model.pkl')
if rf_model is None:
    print("Warning: Could not load Random Forest model.")
    raise RuntimeError("Failed to load Random Forest model. Please check your model file.")

print("All available models and preprocessors loaded successfully.")

@app.route('/')
def home():
    return render_template('index.html')

# Test endpoint to quickly check model loading and prediction
@app.route('/test')
def test_prediction():
    # Create a test request context with form data
    test_data = {
        'no_of_adults': '2',
        'no_of_children': '0',
        'no_of_weekend_nights': '1',
        'no_of_week_nights': '3',
        'type_of_meal_plan': 'Meal Plan 1',
        'required_car_parking_space': '0',
        'room_type_reserved': 'Room_Type 1',
        'lead_time': '45',
        'arrival_year': '2023',
        'arrival_month': '7',
        'arrival_date': '15',
        'market_segment_type': 'Online',
        'repeated_guest': '0',
        'no_of_previous_cancellations': '0',
        'no_of_previous_bookings_not_canceled': '0',
        'no_of_special_requests': '1',
        'avg_price_per_room': '75.5'
    }
    
    # Call the predict function directly with the test data
    with app.test_request_context('/predict', method='POST', data=test_data):
        return predict()

@app.route('/predict', methods=['POST'])
def predict():
    print("=== /predict route was called ===")
    if request.method == 'POST':
        try:
            print("\n=== Starting Prediction ===")
            print("Form data received:", request.form.to_dict())

            # Map form fields to model fields
            field_mapping = {
                'no_of_adults': 'number of adults',
                'no_of_children': 'number of children',
                'no_of_weekend_nights': 'number of weekend nights',
                'no_of_week_nights': 'number of week nights',
                'type_of_meal_plan': 'type of meal',
                'required_car_parking_space': 'car parking space',
                'room_type_reserved': 'room type',
                'lead_time': 'lead time',
                'market_segment_type': 'market segment type',
                'repeated_guest': 'repeated',
                'no_of_previous_cancellations': 'P-C',
                'no_of_previous_bookings_not_canceled': 'P-not-C',
                'avg_price_per_room': 'average price ',  # Note the trailing space
                'no_of_special_requests': 'special requests'
            }

            # Ensure all required columns are present
            required_columns = [
                'number of adults', 'number of children', 'number of weekend nights',
                'number of week nights', 'type of meal', 'car parking space', 'room type',
                'lead time', 'market segment type', 'repeated', 'P-C', 'P-not-C',
                'average price ', 'special requests'
            ]

            processed_data = {}
            for form_field, model_field in field_mapping.items():
                value = request.form.get(form_field, '')
                try:
                    if form_field in [
                        'no_of_adults', 'no_of_children', 'no_of_weekend_nights',
                        'no_of_week_nights', 'required_car_parking_space', 'lead_time',
                        'arrival_year', 'arrival_month', 'arrival_date', 'repeated_guest',
                        'no_of_previous_cancellations', 'no_of_previous_bookings_not_canceled',
                        'no_of_special_requests']:
                        processed_data[model_field] = int(float(value)) if str(value).strip() else 0
                    elif form_field == 'avg_price_per_room':
                        processed_data[model_field] = float(value) if str(value).strip() else 0.0
                    else:
                        processed_data[model_field] = str(value) if value else ''
                    print(f"Processed {form_field} -> {model_field}: {processed_data[model_field]}")
                except Exception as e:
                    print(f"Error processing field {form_field}: {str(e)}")
                    processed_data[model_field] = 0

            # After processed_data is built, check for missing columns
            missing_columns = [col for col in required_columns if col not in processed_data]
            if missing_columns:
                error_msg = f"Error: Missing required input columns: {missing_columns}"
                print(error_msg)
                return render_template('index.html', error=error_msg)

            import pandas as pd
            input_df = pd.DataFrame([processed_data])
            print("\n=== Input Data ===")
            print("Columns:", input_df.columns.tolist())
            print("Data types:", input_df.dtypes)
            print("First row values:", input_df.iloc[0].to_dict())

            results = {}
            status_map = {0: 'Canceled', 1: 'Not Canceled'}

            try:
                final_input = input_df
                if preprocessor is not None:
                    print("\n[1/3] Applying preprocessor...")
                    final_input = preprocessor.transform(final_input)
                    print(f"After preprocessor - Type: {type(final_input)}")
                    if hasattr(final_input, 'shape'):
                        print(f"Shape: {final_input.shape}")
                if selector is not None and hasattr(selector, 'transform'):
                    print("\n[2/3] Applying feature selector...")
                    if hasattr(final_input, 'toarray'):
                        final_input = final_input.toarray()
                    final_input = selector.transform(final_input)
                    print(f"After selector - Type: {type(final_input)}")
                    if hasattr(final_input, 'shape'):
                        print(f"Shape: {final_input.shape}")
                if pca is not None and hasattr(pca, 'transform'):
                    print("\n[3/3] Applying PCA...")
                    if hasattr(final_input, 'toarray'):
                        final_input = final_input.toarray()
                    final_input = pca.transform(final_input)
                    print(f"After PCA - Type: {type(final_input)}")
                    if hasattr(final_input, 'shape'):
                        print(f"Shape: {final_input.shape}")

                # Helper for safe prediction
                def safe_predict(model, input_data, model_name):
                    try:
                        print(f"\n--- Making prediction with {model_name} ---")
                        if hasattr(input_data, 'toarray'):
                            input_data = input_data.toarray()
                        if len(input_data.shape) == 1:
                            input_data = input_data.reshape(1, -1)
                        pred = model.predict(input_data)
                        print(f"Raw prediction output: {pred}")
                        return pred[0] if hasattr(pred, '__len__') and len(pred) > 0 else pred
                    except Exception as e:
                        print(f"{model_name} prediction error: {str(e)}")
                        import traceback
                        traceback.print_exc()
                        return None

                # Random Forest only
                if rf_model is not None:
                    rf_pred = safe_predict(rf_model, final_input, 'Random Forest')
                    results['rf'] = status_map.get(rf_pred, 'Unknown')
                    print(f"Random Forest prediction: {results['rf']}")

                input_data = input_df.iloc[0].to_dict()
                for key, value in input_data.items():
                    if hasattr(value, 'item'):
                        input_data[key] = value.item()
                return render_template('index.html',
                                      rf_result=results.get('rf'),
                                      input_data=input_data)
            except Exception as e:
                error_msg = f"Error during prediction: {str(e)}"
                print(error_msg)
                import traceback
                traceback.print_exc()
                input_data = input_df.iloc[0].to_dict() if 'input_df' in locals() else {}
                for key, value in input_data.items():
                    if hasattr(value, 'item'):
                        input_data[key] = value.item()
                return render_template('index.html', error=error_msg, input_data=input_data)
        except Exception as e:
            error_msg = f"Error processing request: {str(e)}"
            print(error_msg)
            import traceback
            traceback.print_exc()
            return render_template('index.html', error=error_msg)

# /test endpoint for automated health check
def get_test_form_data():
    return {
        'no_of_adults': '2',
        'no_of_children': '0',
        'no_of_weekend_nights': '1',
        'no_of_week_nights': '3',
        'type_of_meal_plan': 'Meal Plan 1',
        'required_car_parking_space': '0',
        'room_type_reserved': 'Room_Type 1',
        'lead_time': '45',
        'arrival_year': '2023',
        'arrival_month': '7',
        'arrival_date': '15',
        'market_segment_type': 'Online',
        'repeated_guest': '0',
        'no_of_previous_cancellations': '0',
        'no_of_previous_bookings_not_canceled': '0',
        'no_of_special_requests': '1',
        'avg_price_per_room': '75.5'
    }

if __name__ == '__main__':
    app.run(debug=True)  # Turn off debug in production