from flask import Flask, request, render_template
import joblib
import numpy as np
import pandas as pd

app = Flask(__name__)


pipeline, feature_names = joblib.load("hotel_booking_random_forest_model_and_features.joblib")

@app.route('/')
def home():
    return render_template("index.html", feature_names=feature_names)


@app.route("/predict", methods=["POST"])
def predict():
    input_data = [float(request.form.get(f, 0)) for f in feature_names]
    final_input = pd.DataFrame([input_data], columns=feature_names)
    prediction = pipeline.predict(final_input)[0]
    return render_template("result.html", prediction_text=f"Prediction: {prediction}")

if __name__ == '__main__':
    app.run(debug=True)
